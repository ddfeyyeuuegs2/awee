import { useState, useRef, useCallback, useEffect } from "react";

// ==================== TYPES ====================
type Tool = "brush" | "eraser" | "line" | "rect" | "circle" | "fill" | "text";
interface Point { x: number; y: number; }

// ==================== SVG ICONS ====================
const S = {
  brush: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg>,
  eraser: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7 21h10"/><path d="M5.5 13.5L17 2l5 5L10.5 18.5 5.5 13.5z"/><path d="M3 21l5.5-5.5"/></svg>,
  line: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="4" y1="20" x2="20" y2="4"/></svg>,
  rect: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>,
  circle: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="9"/></svg>,
  fill: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 22l1-1h3l9-9"/><path d="M3 21V18"/><path d="M12 8l4-4 4 4-8 8-4-4z"/><path d="M20 17a2 2 0 1 1 0 4c-1.5 0-3-2-3-2s1.5-2 3-2z"/></svg>,
  text: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9" y1="20" x2="15" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg>,
  undo: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>,
  redo: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>,
  trash: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>,
  download: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  share: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>,
  fullscreen: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/><path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/></svg>,
  exitFs: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 14h6v6"/><path d="M20 10h-6V4"/><path d="M14 10l7-7"/><path d="M3 21l7-7"/></svg>,
  settings: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  close: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  palette: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="13.5" cy="6.5" r="2"/><circle cx="17.5" cy="10.5" r="2"/><circle cx="8.5" cy="7.5" r="2"/><circle cx="6.5" cy="12.5" r="2"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>,
  check: <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>,
};

const COLORS = [
  "#000000","#ffffff","#ff0000","#ff5722","#ff9800",
  "#ffeb3b","#4caf50","#00bcd4","#2196f3","#3f51b5",
  "#9c27b0","#e91e63","#795548","#607d8b","#9e9e9e",
  "#f44336","#8bc34a","#03a9f4","#673ab7","#ff6f00",
  "#1de9b6","#f06292","#ba68c8","#64b5f6","#81c784",
];
const BG_COLORS = [
  "#ffffff","#f5f5dc","#fafafa","#e8e8e8",
  "#1e1e2e","#2d2d2d","#000000","#e8f5e9",
  "#fce4ec","#e3f2fd","#fff3e0","#f3e5f5",
];
const TOOLS: { id: Tool; name: string }[] = [
  { id: "brush", name: "قلم" },
  { id: "eraser", name: "پاک‌کن" },
  { id: "line", name: "خط" },
  { id: "rect", name: "مستطیل" },
  { id: "circle", name: "دایره" },
  { id: "fill", name: "سطل رنگ" },
  { id: "text", name: "متن" },
];
const TN: Record<Tool, string> = { brush:"قلم", eraser:"پاک‌کن", line:"خط", rect:"مستطیل", circle:"دایره", fill:"سطل رنگ", text:"متن" };

export default function App() {
  const bgRef = useRef<HTMLCanvasElement>(null);
  const drawRef = useRef<HTMLCanvasElement>(null);
  const overRef = useRef<HTMLCanvasElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);

  const [tool, setTool] = useState<Tool>("brush");
  const [color, setColor] = useState("#ff0000");
  const [size, setSize] = useState(6);
  const [bg, setBg] = useState("#ffffff");
  const [opa, setOpa] = useState(100);
  const [isFs, setIsFs] = useState(false);
  const [showClear, setShowClear] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [toast, setToast] = useState("");
  const [showToast, setShowToast] = useState(false);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [toolPanel, setToolPanel] = useState(false);

  const drawing = useRef(false);
  const last = useRef<Point | null>(null);
  const start = useRef<Point | null>(null);
  const curBg = useRef("#ffffff");
  const hist = useRef<ImageData[]>([]);
  const hIdx = useRef(-1);

  const flash = (m: string) => { setToast(m); setShowToast(true); setTimeout(() => setShowToast(false), 2200); };
  const updHist = () => { setCanUndo(hIdx.current > 0); setCanRedo(hIdx.current < hist.current.length - 1); };

  const saveH = useCallback(() => {
    const c = drawRef.current; if (!c) return;
    const d = c.getContext("2d")!.getImageData(0, 0, c.width, c.height);
    if (hIdx.current < hist.current.length - 1) hist.current = hist.current.slice(0, hIdx.current + 1);
    if (hist.current.length >= 50) hist.current.shift();
    hist.current.push(d);
    hIdx.current = hist.current.length - 1;
    updHist();
  }, []);

  const initC = useCallback(() => {
    const b = bgRef.current, d = drawRef.current, o = overRef.current, box = boxRef.current;
    if (!b || !d || !o || !box) return;
    const w = box.clientWidth, h = box.clientHeight, dpr = window.devicePixelRatio || 1;
    [b, d, o].forEach(c => { c.width = w * dpr; c.height = h * dpr; c.style.width = w + "px"; c.style.height = h + "px"; c.getContext("2d")!.setTransform(dpr, 0, 0, dpr, 0, 0); });
    const ctx = b.getContext("2d")!; ctx.fillStyle = curBg.current; ctx.fillRect(0, 0, w, h);
    d.getContext("2d")!.clearRect(0, 0, w, h);
    hist.current = []; hIdx.current = -1; saveH();
  }, [saveH]);

  useEffect(() => {
    initC(); window.scrollTo(0, 1);
    const onResize = () => {
      const d = drawRef.current, box = boxRef.current; if (!d || !box) return;
      const tmp = document.createElement("canvas"); tmp.width = d.width; tmp.height = d.height;
      tmp.getContext("2d")!.drawImage(d, 0, 0);
      const w = box.clientWidth, h = box.clientHeight, dpr = window.devicePixelRatio || 1;
      [bgRef.current!, drawRef.current!, overRef.current!].forEach(c => { c.width = w * dpr; c.height = h * dpr; c.style.width = w + "px"; c.style.height = h + "px"; c.getContext("2d")!.setTransform(dpr, 0, 0, dpr, 0, 0); });
      const bgCtx = bgRef.current!.getContext("2d")!; bgCtx.fillStyle = curBg.current; bgCtx.fillRect(0, 0, w, h);
      drawRef.current!.getContext("2d")!.drawImage(tmp, 0, 0, tmp.width, tmp.height, 0, 0, w, h);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [initC]);

  useEffect(() => {
    const h = () => setIsFs(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", h);
    return () => document.removeEventListener("fullscreenchange", h);
  }, []);

  const toggleFs = async () => { try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); } catch { flash("پشتیبانی نمی‌شود"); } };

  const undo = () => { if (hIdx.current <= 0) return; hIdx.current--; const c = drawRef.current; if (!c) return; const ctx = c.getContext("2d")!; ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,c.width,c.height); ctx.putImageData(hist.current[hIdx.current],0,0); ctx.restore(); updHist(); };
  const redo = () => { if (hIdx.current >= hist.current.length - 1) return; hIdx.current++; const c = drawRef.current; if (!c) return; const ctx = c.getContext("2d")!; ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,c.width,c.height); ctx.putImageData(hist.current[hIdx.current],0,0); ctx.restore(); updHist(); };

  const getP = (e: React.TouchEvent | React.MouseEvent): Point => {
    const r = drawRef.current!.getBoundingClientRect();
    if ("touches" in e && e.touches.length > 0) return { x: e.touches[0].clientX - r.left, y: e.touches[0].clientY - r.top };
    const m = e as React.MouseEvent; return { x: m.clientX - r.left, y: m.clientY - r.top };
  };

  const setupCtx = (ctx: CanvasRenderingContext2D, isE: boolean) => {
    ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.lineWidth = size;
    if (isE) { ctx.globalCompositeOperation = "destination-out"; ctx.globalAlpha = 1; ctx.strokeStyle = "rgba(0,0,0,1)"; ctx.fillStyle = "rgba(0,0,0,1)"; }
    else { ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = opa / 100; ctx.strokeStyle = color; ctx.fillStyle = color; }
  };

  const floodFill = (sx: number, sy: number, fc: string) => {
    const c = drawRef.current, box = boxRef.current; if (!c || !box) return;
    const ctx = c.getContext("2d")!; const dpr = window.devicePixelRatio || 1;
    const px = Math.floor(sx * dpr), py = Math.floor(sy * dpr), w = c.width, h = c.height;
    const m = document.createElement("canvas"); m.width = w; m.height = h;
    const mc = m.getContext("2d")!; mc.drawImage(bgRef.current!, 0, 0); mc.drawImage(c, 0, 0);
    const md = mc.getImageData(0, 0, w, h).data;
    const hex2rgb = (hex: string) => [parseInt(hex.slice(1,3),16), parseInt(hex.slice(3,5),16), parseInt(hex.slice(5,7),16), 255];
    const fill = hex2rgb(fc);
    const idx = (py * w + px) * 4; if (idx < 0 || idx >= md.length) return;
    const tgt = [md[idx], md[idx+1], md[idx+2], md[idx+3]];
    if (tgt[0]===fill[0] && tgt[1]===fill[1] && tgt[2]===fill[2] && tgt[3]===fill[3]) return;
    const match = (i: number) => Math.abs(md[i]-tgt[0])<25 && Math.abs(md[i+1]-tgt[1])<25 && Math.abs(md[i+2]-tgt[2])<25 && Math.abs(md[i+3]-tgt[3])<25;
    const dd = ctx.getImageData(0, 0, w, h); const d = dd.data;
    const vis = new Uint8Array(w * h); const stk: number[] = [px, py];
    while (stk.length > 0) { const cy2 = stk.pop()!, cx = stk.pop()!; if (cx<0||cx>=w||cy2<0||cy2>=h) continue; const ci=cy2*w+cx; if (vis[ci]) continue; const pi=ci*4; if (!match(pi)) continue; vis[ci]=1; d[pi]=fill[0]; d[pi+1]=fill[1]; d[pi+2]=fill[2]; d[pi+3]=fill[3]; stk.push(cx+1,cy2,cx-1,cy2,cx,cy2+1,cx,cy2-1); }
    ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.putImageData(dd, 0, 0); ctx.restore(); saveH();
  };

  const onStart = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault(); const p = getP(e); drawing.current = true; last.current = p; start.current = p;
    if (tool === "fill") { floodFill(p.x, p.y, color); drawing.current = false; return; }
    if (tool === "text") { const t = prompt("متن خود را وارد کنید:"); if (t) { const ctx = drawRef.current!.getContext("2d")!; ctx.globalAlpha = opa/100; ctx.globalCompositeOperation = "source-over"; ctx.fillStyle = color; ctx.font = `bold ${size*3}px sans-serif`; ctx.fillText(t, p.x, p.y); ctx.globalAlpha = 1; saveH(); } drawing.current = false; return; }
    if (tool === "brush" || tool === "eraser") { const ctx = drawRef.current!.getContext("2d")!; setupCtx(ctx, tool === "eraser"); ctx.beginPath(); ctx.arc(p.x, p.y, size/2, 0, Math.PI*2); ctx.fill(); }
  };

  const onMove = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault(); if (!drawing.current) return; const p = getP(e);
    if (tool === "brush" || tool === "eraser") {
      const ctx = drawRef.current!.getContext("2d")!; setupCtx(ctx, tool === "eraser");
      if (last.current) { ctx.beginPath(); ctx.moveTo(last.current.x, last.current.y); ctx.lineTo(p.x, p.y); ctx.stroke(); }
      last.current = p;
    } else if (tool === "line" || tool === "rect" || tool === "circle") {
      const o = overRef.current!, box = boxRef.current!; const oc = o.getContext("2d")!;
      oc.clearRect(0, 0, box.clientWidth, box.clientHeight);
      oc.lineCap = "round"; oc.lineJoin = "round"; oc.lineWidth = size; oc.strokeStyle = color; oc.globalAlpha = opa/100; oc.globalCompositeOperation = "source-over";
      const sp = start.current!;
      if (tool === "line") { oc.beginPath(); oc.moveTo(sp.x, sp.y); oc.lineTo(p.x, p.y); oc.stroke(); }
      else if (tool === "rect") { oc.beginPath(); oc.strokeRect(sp.x, sp.y, p.x-sp.x, p.y-sp.y); }
      else { const rx = Math.abs(p.x-sp.x)/2, ry = Math.abs(p.y-sp.y)/2, cx = (sp.x+p.x)/2, cy = (sp.y+p.y)/2; oc.beginPath(); oc.ellipse(cx, cy, rx, ry, 0, 0, Math.PI*2); oc.stroke(); }
      oc.globalAlpha = 1;
    }
  };

  const onEnd = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault(); if (!drawing.current) return; drawing.current = false;
    if (tool === "brush" || tool === "eraser") { const ctx = drawRef.current!.getContext("2d")!; ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1; saveH(); return; }
    if (tool === "line" || tool === "rect" || tool === "circle") {
      const o = overRef.current!, d = drawRef.current!, box = boxRef.current!;
      const ctx = d.getContext("2d")!; ctx.globalAlpha = 1; ctx.globalCompositeOperation = "source-over";
      ctx.save(); ctx.setTransform(1,0,0,1,0,0); ctx.drawImage(o, 0, 0, o.width, o.height, 0, 0, d.width, d.height); ctx.restore();
      o.getContext("2d")!.clearRect(0, 0, box.clientWidth, box.clientHeight); saveH();
    }
    last.current = null; start.current = null;
  };

  const clearC = () => { const ctx = drawRef.current?.getContext("2d"), box = boxRef.current; if (!ctx || !box) return; ctx.clearRect(0, 0, box.clientWidth, box.clientHeight); saveH(); setShowClear(false); flash("صفحه پاک شد ✨"); };

  const changeBg = (c: string) => { setBg(c); curBg.current = c; const ctx = bgRef.current?.getContext("2d"), box = boxRef.current; if (!ctx || !box) return; ctx.fillStyle = c; ctx.fillRect(0, 0, box.clientWidth, box.clientHeight); };

  const dlImg = () => {
    const b = bgRef.current, d = drawRef.current, box = boxRef.current; if (!b || !d || !box) return;
    const ex = document.createElement("canvas"); const w = box.clientWidth*2, h = box.clientHeight*2; ex.width = w; ex.height = h;
    const ec = ex.getContext("2d")!; ec.drawImage(b, 0, 0, b.width, b.height, 0, 0, w, h); ec.drawImage(d, 0, 0, d.width, d.height, 0, 0, w, h);
    ex.toBlob(async blob => {
      if (!blob) return;
      if (navigator.share && navigator.canShare) { const f = new File([blob], `painting-${Date.now()}.png`, { type: "image/png" }); const sd = { files: [f], title: "نقاشی من" }; try { if (navigator.canShare(sd)) { await navigator.share(sd); flash("ذخیره شد! 🎉"); return; } } catch {} }
      const l = document.createElement("a"); l.download = `painting-${Date.now()}.png`; l.href = URL.createObjectURL(blob); l.click(); URL.revokeObjectURL(l.href); flash("تصویر ذخیره شد! 💾");
    }, "image/png");
  };

  const shareImg = () => {
    const b = bgRef.current, d = drawRef.current, box = boxRef.current; if (!b || !d || !box) return;
    const ex = document.createElement("canvas"); ex.width = box.clientWidth*2; ex.height = box.clientHeight*2;
    const ec = ex.getContext("2d")!; ec.drawImage(b, 0, 0, b.width, b.height, 0, 0, ex.width, ex.height); ec.drawImage(d, 0, 0, d.width, d.height, 0, 0, ex.width, ex.height);
    ex.toBlob(async blob => {
      if (!blob) return;
      if (navigator.share) { const f = new File([blob], "painting.png", { type: "image/png" }); try { await navigator.share({ files: [f], title: "نقاشی من", text: "این نقاشی رو ببین! 🎨" }); flash("اشتراک شد! 🎉"); } catch { flash("لغو شد"); } } else dlImg();
    }, "image/png");
  };

  const ic = (t: Tool) => S[t];
  const TB = ({ t }: { t: Tool }) => (
    <button onClick={() => { setTool(t); setToolPanel(false); }}
      className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-200 ${tool === t ? "bg-gradient-to-br from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/30 scale-105" : "bg-gray-700/50 text-gray-300 hover:bg-gray-600 active:scale-95"}`}>
      <span className="w-5 h-5">{ic(t)}</span>
      <span className="text-[10px] mt-1.5 font-bold">{TN[t]}</span>
    </button>
  );

  return (
    <div className="w-full h-full flex flex-col bg-[#1e1e2e] overflow-hidden relative" style={{ height: "100dvh" }}>
      {/* Canvas */}
      <div ref={boxRef} className="absolute inset-0 overflow-hidden">
        <canvas ref={bgRef} className="absolute top-0 left-0" />
        <canvas ref={drawRef} className="absolute top-0 left-0 cursor-crosshair"
          onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={onEnd}
          onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd} onTouchCancel={onEnd} />
        <canvas ref={overRef} className="absolute top-0 left-0 pointer-events-none" />
        {tool === "eraser" && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-orange-500/90 text-white text-xs px-4 py-1.5 rounded-full font-bold flex items-center gap-2 pointer-events-none shadow-lg animate-scaleIn z-20">
            <span className="w-4 h-4">{S.eraser}</span> حالت پاک‌کن
          </div>
        )}
      </div>

      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-2 py-2 pointer-events-none">
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button onClick={() => { setToolPanel(!toolPanel); setShowSettings(false); }}
            className="p-2.5 rounded-2xl bg-[#1e1e2e]/80 backdrop-blur-md text-white shadow-lg border border-gray-700/40 active:scale-90 transition-all">
            <span className="w-5 h-5 block">{toolPanel ? S.close : ic(tool)}</span>
          </button>
          <div className="flex items-center gap-1.5 bg-[#1e1e2e]/80 backdrop-blur-md rounded-2xl px-3 py-2 shadow-lg border border-gray-700/40">
            <div className="w-3.5 h-3.5 rounded-full border-2 border-white/50 shrink-0" style={{ backgroundColor: tool === "eraser" ? "#f97316" : color }} />
            <span className="text-white font-bold text-[11px]">{TN[tool]}</span>
          </div>
        </div>
        <div className="flex items-center gap-1.5 pointer-events-auto">
          <button onClick={undo} disabled={!canUndo}
            className={`p-2.5 rounded-2xl shadow-lg border border-gray-700/40 transition-all active:scale-90 ${canUndo ? "bg-[#1e1e2e]/80 backdrop-blur-md text-white" : "bg-[#1e1e2e]/50 text-gray-600"}`}>
            <span className="w-5 h-5 block">{S.undo}</span>
          </button>
          <button onClick={redo} disabled={!canRedo}
            className={`p-2.5 rounded-2xl shadow-lg border border-gray-700/40 transition-all active:scale-90 ${canRedo ? "bg-[#1e1e2e]/80 backdrop-blur-md text-white" : "bg-[#1e1e2e]/50 text-gray-600"}`}>
            <span className="w-5 h-5 block">{S.redo}</span>
          </button>
          <button onClick={() => { setShowSettings(true); setToolPanel(false); }}
            className="p-2.5 rounded-2xl bg-[#1e1e2e]/80 backdrop-blur-md text-white shadow-lg border border-gray-700/40 active:scale-90 transition-all">
            <span className="w-5 h-5 block">{S.settings}</span>
          </button>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="absolute bottom-0 left-0 right-0 z-30 px-2 pb-3 pt-1 pointer-events-none">
        <div className="pointer-events-auto bg-[#1e1e2e]/85 backdrop-blur-xl rounded-3xl p-3 shadow-2xl border border-gray-700/30">
          <div className="flex items-center gap-2 mb-2.5 px-1">
            <div className="w-4 h-4 flex items-center justify-center shrink-0"><div className="w-1.5 h-1.5 rounded-full bg-gray-400" /></div>
            <input type="range" min="1" max="50" value={size} onChange={e => setSize(Number(e.target.value))} className="flex-1" />
            <div className="w-4 h-4 flex items-center justify-center shrink-0"><div className="w-4 h-4 rounded-full bg-gray-400" /></div>
            <div className="bg-gray-700/70 px-2 py-0.5 rounded-lg min-w-[36px] text-center"><span className="text-white text-[11px] font-bold">{size}</span></div>
            <div className="flex items-center justify-center w-9 h-9 shrink-0">
              <div className="rounded-full transition-all duration-150 border border-gray-500/30"
                style={{ width: Math.max(3, Math.min(size, 36)), height: Math.max(3, Math.min(size, 36)), backgroundColor: tool === "eraser" ? "#f97316" : color, opacity: tool === "eraser" ? 1 : opa/100 }} />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative shrink-0"><input type="color" value={color} onChange={e => { setColor(e.target.value); if (tool === "eraser") setTool("brush"); }} className="w-9 h-9" /></div>
            <div className="flex gap-1 overflow-x-auto flex-1 py-1 px-0.5" style={{ scrollbarWidth: "none" }}>
              {COLORS.slice(0, 14).map(c => (
                <button key={c} onClick={() => { setColor(c); if (tool === "eraser") setTool("brush"); }}
                  className={`w-6 h-6 rounded-full shrink-0 border-2 transition-all duration-150 ${color === c && tool !== "eraser" ? "border-white scale-125 shadow-lg" : "border-transparent"}`}
                  style={{ backgroundColor: c }} />
              ))}
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={() => setTool(tool === "eraser" ? "brush" : "eraser")}
                className={`p-2 rounded-xl transition-all active:scale-90 ${tool === "eraser" ? "bg-orange-500 text-white shadow-lg shadow-orange-500/40" : "bg-gray-700/60 text-gray-400"}`}>
                <span className="w-5 h-5 block">{S.eraser}</span>
              </button>
              <button onClick={dlImg} className="p-2 rounded-xl bg-green-500/20 text-green-400 transition-all active:scale-90">
                <span className="w-5 h-5 block">{S.download}</span>
              </button>
              <button onClick={() => setShowClear(true)} className="p-2 rounded-xl bg-red-500/20 text-red-400 transition-all active:scale-90">
                <span className="w-5 h-5 block">{S.trash}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tool Panel */}
      {toolPanel && (
        <div className="absolute inset-0 z-40 animate-fadeIn" onClick={() => setToolPanel(false)}>
          <div className="absolute top-14 left-2 bg-[#1a1a2e]/95 backdrop-blur-xl rounded-3xl p-4 shadow-2xl border border-gray-700/30 animate-scaleIn w-[280px]" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold text-sm mb-3">🎨 انتخاب ابزار</h3>
            <div className="grid grid-cols-4 gap-2">{TOOLS.map(t => <TB key={t.id} t={t.id} />)}</div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettings && (
        <div className="absolute inset-0 z-50 flex items-end justify-center animate-fadeIn" onClick={() => setShowSettings(false)}>
          <div className="w-full max-w-lg bg-[#1a1a2e]/98 backdrop-blur-2xl border-t border-gray-700/30 rounded-t-3xl p-5 pb-8 max-h-[85vh] overflow-y-auto animate-slideUp" onClick={e => e.stopPropagation()} style={{ scrollbarWidth: "none" }}>
            <div className="w-12 h-1.5 bg-gray-600 rounded-full mx-auto mb-4" />
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-white font-bold text-lg">⚙️ تنظیمات</h3>
              <button onClick={() => setShowSettings(false)} className="p-2 rounded-xl bg-gray-700/40 text-gray-400 active:scale-90 transition-all"><span className="w-5 h-5 block">{S.close}</span></button>
            </div>

            {/* Size */}
            <div className="bg-gray-800/50 rounded-2xl p-4 mb-3">
              <label className="text-gray-300 text-sm mb-3 flex items-center justify-between"><span className="font-bold">📏 ضخامت قلم</span><span className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-lg text-xs font-bold">{size}px</span></label>
              <input type="range" min="1" max="50" value={size} onChange={e => setSize(Number(e.target.value))} className="w-full mt-2" />
              <div className="flex justify-center mt-3"><div className="rounded-full transition-all duration-200 border border-gray-500/20" style={{ width: Math.max(4, size), height: Math.max(4, size), backgroundColor: tool === "eraser" ? "#f97316" : color }} /></div>
              <div className="flex gap-2 mt-3 justify-center flex-wrap">
                {[1,3,6,12,20,35,50].map(s => <button key={s} onClick={() => setSize(s)} className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${size === s ? "bg-blue-500 text-white" : "bg-gray-700 text-gray-400"}`}>{s}</button>)}
              </div>
            </div>

            {/* Opacity */}
            <div className="bg-gray-800/50 rounded-2xl p-4 mb-3">
              <label className="text-gray-300 text-sm mb-3 flex items-center justify-between"><span className="font-bold">🔅 شفافیت</span><span className="bg-purple-500/20 text-purple-400 px-3 py-1 rounded-lg text-xs font-bold">{opa}%</span></label>
              <input type="range" min="5" max="100" value={opa} onChange={e => setOpa(Number(e.target.value))} className="w-full mt-2" />
            </div>

            {/* Color */}
            <div className="bg-gray-800/50 rounded-2xl p-4 mb-3">
              <label className="text-gray-300 text-sm mb-3 flex items-center justify-between">
                <span className="font-bold flex items-center gap-1.5"><span className="w-5 h-5">{S.palette}</span> انتخاب رنگ</span>
                <span className="flex items-center gap-2"><span className="w-6 h-6 rounded-full border-2 border-white/50 inline-block" style={{ backgroundColor: color }} /><span className="text-gray-400 text-xs font-mono">{color}</span></span>
              </label>
              <div className="flex items-center gap-3 mb-4 bg-gray-700/30 rounded-xl p-3">
                <input type="color" value={color} onChange={e => setColor(e.target.value)} className="w-12 h-12 rounded-xl cursor-pointer" />
                <div><p className="text-white text-sm font-bold">انتخاب رنگ دلخواه</p><p className="text-gray-400 text-xs mt-0.5">هر رنگی که می‌خواهید</p></div>
              </div>
              <div className="grid grid-cols-5 gap-2.5">
                {COLORS.map(c => <button key={c} onClick={() => setColor(c)} className={`w-full aspect-square rounded-xl border-2 transition-all duration-200 ${color === c ? "border-white scale-110 shadow-lg shadow-white/10" : "border-gray-600/30"}`} style={{ backgroundColor: c }} />)}
              </div>
            </div>

            {/* BG */}
            <div className="bg-gray-800/50 rounded-2xl p-4 mb-3">
              <label className="text-gray-300 text-sm mb-3 block font-bold">🖼️ رنگ پس‌زمینه</label>
              <div className="grid grid-cols-4 gap-2.5">
                {BG_COLORS.map(c => <button key={c} onClick={() => changeBg(c)} className={`h-10 rounded-xl border-2 transition-all duration-200 ${bg === c ? "border-blue-400 scale-105 shadow-lg shadow-blue-500/20" : "border-gray-600/30"}`} style={{ backgroundColor: c }} />)}
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              <button onClick={() => { setShowSettings(false); dlImg(); }} className="flex flex-col items-center p-3 rounded-2xl bg-green-500/15 text-green-400 active:scale-95 transition-all"><span className="w-6 h-6">{S.download}</span><span className="text-[10px] mt-1 font-bold">ذخیره</span></button>
              <button onClick={() => { setShowSettings(false); shareImg(); }} className="flex flex-col items-center p-3 rounded-2xl bg-blue-500/15 text-blue-400 active:scale-95 transition-all"><span className="w-6 h-6">{S.share}</span><span className="text-[10px] mt-1 font-bold">اشتراک</span></button>
              <button onClick={() => { setShowClear(true); setShowSettings(false); }} className="flex flex-col items-center p-3 rounded-2xl bg-red-500/15 text-red-400 active:scale-95 transition-all"><span className="w-6 h-6">{S.trash}</span><span className="text-[10px] mt-1 font-bold">پاک کردن</span></button>
            </div>

            <button onClick={toggleFs} className="w-full py-3.5 bg-indigo-500/15 text-indigo-400 rounded-2xl font-bold transition-all mb-3 flex items-center justify-center gap-2 active:scale-[0.98]">
              <span className="w-5 h-5">{isFs ? S.exitFs : S.fullscreen}</span>{isFs ? "خروج از تمام‌صفحه" : "حالت تمام‌صفحه"}
            </button>
            <button onClick={() => setShowSettings(false)} className="w-full py-3.5 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-2xl font-bold transition-all active:scale-[0.98] shadow-lg shadow-blue-500/20">تأیید ✓</button>
          </div>
        </div>
      )}

      {/* Confirm */}
      {showClear && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 animate-fadeIn" onClick={() => setShowClear(false)}>
          <div className="bg-[#2a2a3e] rounded-3xl p-6 mx-6 max-w-sm w-full shadow-2xl animate-scaleIn border border-gray-600/30" onClick={e => e.stopPropagation()}>
            <h3 className="text-white font-bold text-lg mb-2">🗑️ پاک کردن صفحه</h3>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">آیا مطمئن هستید؟ تمام نقاشی شما پاک خواهد شد!</p>
            <div className="flex gap-3">
              <button onClick={() => setShowClear(false)} className="flex-1 py-3 rounded-2xl bg-gray-700 text-gray-300 font-bold active:scale-95">انصراف</button>
              <button onClick={clearC} className="flex-1 py-3 rounded-2xl bg-red-500 text-white font-bold active:scale-95">بله، پاک شود</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {showToast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[200] animate-scaleIn">
          <div className="bg-green-500 text-white px-6 py-3 rounded-2xl shadow-2xl font-bold text-sm flex items-center gap-2">
            <span className="w-5 h-5">{S.check}</span>{toast}
          </div>
        </div>
      )}
    </div>
  );
}
